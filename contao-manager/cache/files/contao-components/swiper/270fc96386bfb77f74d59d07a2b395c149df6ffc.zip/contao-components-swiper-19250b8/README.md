Swiper
======

This is a customized package of [Swiper][1] to be integrated in
[Contao Open Source CMS][2].


[1]: https://swiperjs.com
[2]: https://contao.org

<?php

return [
    'Names' => [
        'NAD' => [
            '$',
            'Namibian Dollar',
        ],
    ],
];

<?php

return [
    'Names' => [
        'FJD' => [
            '$',
            'Fijian Dollar',
        ],
    ],
];

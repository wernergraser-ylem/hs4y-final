<?php

return [
    'Names' => [
        'LUF' => [
            'F',
            'Luxemburgischer Franc',
        ],
    ],
];

<?php

return [
    'Names' => [
        'BTN' => [
            'BTN',
            'ngultrum butanés',
        ],
        'ETB' => [
            'ETB',
            'birr',
        ],
        'JPY' => [
            '¥',
            'yen japonés',
        ],
        'THB' => [
            'THB',
            'bat',
        ],
        'USD' => [
            '$',
            'dólar estadounidense',
        ],
        'UZS' => [
            'UZS',
            'sum',
        ],
        'XAF' => [
            'XAF',
            'franco CFA de África central',
        ],
        'ZMW' => [
            'ZMW',
            'kwacha zambiano',
        ],
    ],
];

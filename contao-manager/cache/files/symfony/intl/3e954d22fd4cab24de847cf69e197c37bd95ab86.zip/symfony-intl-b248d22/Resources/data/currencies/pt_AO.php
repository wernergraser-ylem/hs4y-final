<?php

return [
    'Names' => [
        'AOA' => [
            'Kz',
            'kwanza angolano',
        ],
    ],
];

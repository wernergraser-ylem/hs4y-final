<?php

return [
    'Names' => [
        'EUR' => [
            'EUR',
            'Euro',
        ],
    ],
];

<?php

return [
    'Names' => [
        'MRU' => [
            'UM',
            'Ugiyya Muritani',
        ],
    ],
];

<?php

return [
    'Names' => [
        'ANG' => [
            'ANG',
            'florín de las Antillas Neerlandesas',
        ],
        'BMD' => [
            'BMD',
            'dólar de Bermudas',
        ],
        'EUR' => [
            'EUR',
            'euro',
        ],
        'HTG' => [
            'HTG',
            'gourde haitiano',
        ],
        'KZT' => [
            'KZT',
            'tenge kazajo',
        ],
        'MWK' => [
            'MWK',
            'kwacha malauí',
        ],
        'NIO' => [
            'NIO',
            'córdoba nicaragüense',
        ],
        'SLE' => [
            'SLE',
            'leone',
        ],
        'SLL' => [
            'SLL',
            'leones (1964—2022)',
        ],
        'THB' => [
            'THB',
            'baht tailandes',
        ],
        'USD' => [
            'USD',
            'dólar estadounidense',
        ],
        'UZS' => [
            'UZS',
            'som uzbeko',
        ],
        'VND' => [
            'VND',
            'dong vietnamita',
        ],
    ],
];
